package mx.edu.u2t2_marcolopez

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
